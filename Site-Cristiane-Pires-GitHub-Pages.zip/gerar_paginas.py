"""Atualiza o HTML de dist/ com Python 3, sem instalar pacotes."""
from base64 import b64encode
from hashlib import sha384
from html import escape
from pathlib import Path

DIST = Path(__file__).resolve().parent / "dist"
BASE = "https://cristianepires-adv.github.io/RegularizacaoDeImoveis/"
NOME = "Cristiane Pires"
OAB = "OAB/SP 436.779"
WHATSAPP = "https://wa.me/5511974609378"
TELEFONE = "(11) 97460-9378"
TEL_URL = "tel:+5511974609378"
EMAIL = "cristianepires.adv@gmail.com"
SCRIPT_HASH = "sha384-" + b64encode(sha384((DIST / "assets/site.js").read_bytes()).digest()).decode("ascii")
CSP = ("default-src 'none'; base-uri 'none'; object-src 'none'; "
       f"script-src '{SCRIPT_HASH}'; script-src-attr 'none'; style-src 'self'; style-src-attr 'none'; "
       "img-src 'self'; font-src 'self'; connect-src 'none'; form-action 'none'; "
       "frame-src 'none'; media-src 'none'; worker-src 'none'")
CPC = "https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2015/lei/l13105.htm"

GUIAS = [
    {
        "slug": "usucapiao", "area": "Usucapião extrajudicial", "icon": "registro",
        "situacao": "Tenho a posse de um imóvel e quero entender como regularizá-lo.",
        "resumo": "Saiba quais informações sobre o imóvel e o tempo de posse ajudam a avaliar uma regularização.",
        "contexto": [
            "Comece pela história do imóvel. Anote quando e como a posse teve início, quem ocupou o bem ao longo dos anos e se houve alguma oposição. Uma linha do tempo ajuda a localizar os documentos mais relevantes.",
            "A usucapião é uma das formas de aquisição da propriedade. Para avaliar se a via extrajudicial se aplica, é preciso examinar a origem da posse, o registro e as circunstâncias do caso. Um contrato ou comprovante isolado conta apenas parte dessa história."
        ],
        "lista": [
            ("Histórico da posse", "Anote as datas aproximadas de entrada no imóvel e de eventuais mudanças de ocupante."),
            ("Contratos e recibos", "Separe contratos, cessões ou comprovantes relacionados à entrada na posse."),
            ("Comprovantes ao longo dos anos", "Organize por data carnês de IPTU, contas ou registros de benfeitorias que já tiver."),
            ("Informações do registro", "Localize a matrícula ou a transcrição, se conhecida, e anote o cartório responsável.")
        ],
        "perguntas": ["Que pontos da minha história de posse precisam de comprovação?", "Os documentos indicam uma forma de regularização mais adequada ao meu caso?"],
        "fontes": [("Lei de Registros Públicos, art. 216-A", "https://www.planalto.gov.br/ccivil_03/leis/l6015compilada.htm#art216a")]
    },
    {
        "slug": "inventario", "area": "Inventário e partilha", "icon": "familia",
        "situacao": "Herdei um imóvel e preciso organizar a partilha da família.",
        "resumo": "Organize as informações sobre a família, os bens e os documentos do imóvel que integra a herança.",
        "contexto": [
            "Uma primeira conversa sobre inventário começa pela composição da família e pelo patrimônio deixado. Se o imóvel ainda estiver registrado em nome de outra pessoa, essa é uma informação importante para levar à análise.",
            "Faça uma lista simples dos bens, de eventuais dívidas e do que já foi providenciado. Informe se existe testamento ou inventário em andamento. Esses elementos ajudam a discutir a via adequada e os próximos atos."
        ],
        "lista": [
            ("Certidão de óbito", "Separe a certidão e anote a data do falecimento."),
            ("Composição da família", "Identifique cônjuge ou companheiro e possíveis herdeiros. Anote dúvidas sobre o parentesco."),
            ("Documentação dos imóveis", "Localize matrículas, escrituras, contratos e dados de IPTU disponíveis."),
            ("Outros bens e providências", "Liste outros bens, dívidas conhecidas e eventual testamento, escritura ou processo já iniciado.")
        ],
        "perguntas": ["Quais documentos faltam para identificar os bens e os interessados?", "Quais prazos e providências merecem atenção na situação da minha família?"],
        "fontes": [("Código de Processo Civil, arts. 610 e 620", CPC+"#art610")]
    },
    {
        "slug": "leiloes", "area": "Leilões de imóveis", "icon": "leilao",
        "situacao": "Encontrei um imóvel em leilão e quero avaliar o edital antes do lance.",
        "resumo": "Veja o que observar no edital, na matrícula e nas condições de ocupação antes de decidir sobre um lance.",
        "contexto": [
            "Guarde o edital completo e seus anexos. Identifique o lote, a modalidade de leilão e quem conduz a venda. Uma descrição resumida no anúncio pode omitir condições importantes para a decisão.",
            "Compare a identificação do imóvel com a matrícula indicada. Destaque as cláusulas sobre pagamento, comissão e despesas, além de qualquer informação sobre ocupação. Se algum ponto estiver em aberto, leve a pergunta antes de assumir um compromisso."
        ],
        "lista": [
            ("Edital completo e alterações", "Guarde a versão mais recente, os anexos, a identificação do lote e as datas anunciadas."),
            ("Matrícula do imóvel", "Separe o documento disponível e confira se número, endereço e descrição correspondem ao lote."),
            ("Condições financeiras", "Marque os trechos sobre pagamento, comissão e responsabilidades por despesas."),
            ("Posse e ocupação", "Anote o que o edital informa sobre ocupantes, visitação e entrega do imóvel.")
        ],
        "perguntas": ["Quais despesas estão atribuídas ao arrematante neste edital?", "Que documentos e informações sobre a ocupação ainda precisam ser examinados?"],
        "fontes": [("Código de Processo Civil, art. 886, sobre leilões judiciais", CPC+"#art886")]
    },
    {
        "slug": "desocupacao", "area": "Desocupação de imóveis", "icon": "chave",
        "situacao": "Preciso entender as opções para retomar a posse de um imóvel.",
        "resumo": "Reúna o histórico da ocupação, os acordos existentes e as comunicações anteriores sobre o imóvel.",
        "contexto": [
            "Comece identificando como a ocupação teve início. Um contrato de locação, um empréstimo do imóvel e uma ocupação sem autorização envolvem relações diferentes. Essa distinção orienta a análise jurídica.",
            "Organize o histórico em ordem de data. Inclua acordos, pagamentos e comunicações já feitos. Se recebeu uma notificação ou documento judicial, destaque a data de recebimento para a conversa com a advogada."
        ],
        "lista": [
            ("Origem da ocupação", "Anote quando ela começou, quem entregou as chaves e o que foi combinado."),
            ("Contratos e registros", "Separe contratos, aditivos, comprovantes de posse ou documentos de propriedade disponíveis."),
            ("Comunicações anteriores", "Reúna notificações e mensagens já trocadas com indicação de data."),
            ("Situação atual", "Registre os acontecimentos recentes e localize eventuais intimações ou processos em andamento.")
        ],
        "perguntas": ["Como a relação com o ocupante afeta as medidas possíveis?", "Existe alguma comunicação recebida ou prazo que deva ser analisado primeiro?"],
        "fontes": [("Lei do Inquilinato, art. 5º", "https://www.planalto.gov.br/ccivil_03/leis/l8245.htm"), ("Código de Processo Civil, arts. 560 e 561", CPC+"#art560")]
    }
]

def icone(nome):
    return f'<span aria-hidden="true" class="icon i-{nome}"></span>'

def botao_whatsapp(texto="Falar no WhatsApp", classe=""):
    return f'<a class="button {classe}" href="{WHATSAPP}" rel="noreferrer">{icone("conversa")}{texto}</a>'

def cabecalho(prefixo, pagina_inicial=False):
    inicio = "#home" if pagina_inicial else prefixo + "index.html#home"
    base_ancora = "" if pagina_inicial else prefixo + "index.html"
    return f'''
  <a class="skip" href="#principal">Pular para o conteúdo</a>
  <header class="site-header" id="topo">
    <div class="shell header-inner">
      <a class="brand" href="{inicio}" aria-label="Cristiane Pires Advocacia, início">
        <img src="{prefixo}assets/monograma.webp" width="39" height="50" alt="">
        <span class="wordmark">{NOME}<span>Advocacia</span></span>
      </a>
      <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="navegacao" hidden><span class="menu-bars" aria-hidden="true"></span>Menu</button>
      <nav id="navegacao" class="nav" aria-label="Navegação principal">
        <a href="{base_ancora}#atuacao">Áreas de atuação</a>
        <a href="{base_ancora}#sobre">O escritório</a>
        <a href="{base_ancora}#duvidas">Dúvidas</a>
        <a class="nav-contact" href="{base_ancora}#contato">{icone("conversa")}Contato</a>
      </nav>
    </div>
  </header>'''

def rodape(prefixo, pagina_inicial=False):
    return f'''
  <footer class="footer">
    <div class="shell footer-inner">
      <a href="{'#home' if pagina_inicial else prefixo+'index.html#home'}" aria-label="Cristiane Pires Advocacia, início">
        <img src="{prefixo}assets/marca-completa.webp" width="106" height="76" loading="lazy" alt="Cristiane Pires Advocacia">
      </a>
      <p>{NOME} Advocacia <span class="footer-sep">·</span> {OAB}</p>
      <a href="{prefixo}privacidade.html">Privacidade</a>
    </div>
  </footer>'''

def documento(caminho, titulo, descricao, corpo, prefixo="", inicial=False):
    url = BASE + ("" if inicial else caminho)
    desc = escape(descricao, quote=True)
    return f'''<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta http-equiv="Content-Security-Policy" content="{CSP}">
  <meta name="referrer" content="no-referrer">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#241f1e">
  <title>{escape(titulo)}</title>
  <meta name="description" content="{desc}">
  <link rel="canonical" href="{url}">
  <meta property="og:locale" content="pt_BR">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Cristiane Pires Advocacia">
  <meta property="og:title" content="{escape(titulo, quote=True)}">
  <meta property="og:description" content="{desc}">
  <meta property="og:url" content="{url}">
  <meta property="og:image" content="{BASE}assets/compartilhar.jpg">
  <meta property="og:image:alt" content="Detalhe ilustrativo de uma fachada residencial">
  <link rel="icon" href="{prefixo}assets/icone.png" type="image/png">
  <link rel="stylesheet" href="{prefixo}assets/site.css">
  <script defer src="{prefixo}assets/site.js" integrity="{SCRIPT_HASH}"></script>
</head>
<body>
{cabecalho(prefixo, inicial)}
{corpo}
{rodape(prefixo, inicial)}
</body>
</html>
'''

def cartao(guia):
    return f'''        <article class="service-card">
          <div class="service-icon">{icone(guia["icon"])}</div>
          <h3><a href="guias/{guia["slug"]}.html" class="card-link">{guia["area"]}</a></h3>
          <p>{guia["situacao"]}</p>
          <span class="card-cue" aria-hidden="true">Consultar guia</span>
        </article>'''

def pagina_inicial():
    cartoes = "\n".join(cartao(guia) for guia in GUIAS)
    return f'''
  <main id="principal" tabindex="-1">
    <section class="hero" id="home" aria-labelledby="titulo">
      <picture class="hero-picture">
        <source media="(max-width: 640px)" srcset="assets/hero-800.webp">
        <img src="assets/hero-1600.webp" width="1600" height="763" alt="" fetchpriority="high">
      </picture>
      <div class="shell hero-layout">
        <div class="hero-copy">
          <p class="eyebrow hero-overline">Direito imobiliário</p>
          <h1 id="titulo">Orientação jurídica<br><em>para o seu imóvel.</em></h1>
          <p class="hero-description">Regularização, herança, leilão ou desocupação. Entenda por onde começar e quais documentos reunir.</p>
          <div class="hero-actions">
            <a class="button light-button" href="#atuacao">{icone("livro")}Explorar os guias</a>
            <a class="hero-textlink" href="#contato">Falar com o escritório</a>
          </div>
        </div>
        <p class="hero-location">{icone("local")}São Paulo, SP</p>
      </div>
    </section>
    <section id="atuacao" aria-labelledby="tit-atuacao" class="areas">
      <div class="shell">
        <div class="section-head">
          <div><p class="eyebrow">Áreas de atuação</p><h2 id="tit-atuacao">Qual é a sua situação?</h2></div>
          <p class="aside-copy">Escolha um tema para consultar as orientações e preparar sua lista de documentos.</p>
        </div>
        <div class="service-grid">
{cartoes}
        </div>
      </div>
    </section>
    <section id="sobre" aria-labelledby="tit-sobre" class="about">
      <div class="shell about-grid">
        <div class="about-visual"><img src="assets/detalhe.webp" width="900" height="600" alt="Chave sobre uma planta de imóvel, imagem ilustrativa" loading="lazy" decoding="async"></div>
        <div class="about-body">
          <p class="eyebrow">O escritório</p>
          <h2 id="tit-sobre">{NOME}</h2>
          <p class="registration">Advogada <span aria-hidden="true">·</span> {OAB}</p>
          <p>Atuo em Direito Imobiliário em São Paulo, com foco em regularização, inventários, arrematação em leilões e questões de posse.</p>
          <p>Uma escritura antiga, um imóvel de família e um edital de leilão levantam perguntas diferentes. Na primeira conversa, você pode contar em que ponto está e o que precisa decidir.</p>
          <a class="underlink" href="#contato">Consultar os canais de atendimento</a>
        </div>
      </div>
    </section>
    <section id="duvidas" class="faq" aria-labelledby="tit-duvidas">
      <div class="shell faq-grid">
        <div><p class="eyebrow">Primeiro contato</p><h2 id="tit-duvidas">Dúvidas frequentes</h2></div>
        <div class="faq-items">
          <details><summary>Tenho apenas um contrato de compra e venda. Por onde começo?</summary>
            <div><p>Localize o contrato e os comprovantes de pagamento. Se souber o número da matrícula e o cartório do imóvel, anote também. Esse conjunto ajuda a avaliar quais caminhos de regularização fazem sentido para o seu caso.</p><a class="underlink" href="guias/usucapiao.html">Ver o guia sobre posse e registro</a></div>
          </details>
          <details><summary>Preciso reunir todos os documentos antes de conversar?</summary>
            <div><p>Você pode começar com os documentos que já tem. Os guias ajudam a organizar o que está disponível e identificar o que ainda precisa ser localizado. A relação definitiva depende da análise de cada caso.</p></div>
          </details>
          <details><summary>Posso falar com o escritório antes de dar um lance?</summary>
            <div><p>Sim. Tenha à mão o edital, a identificação do lote e a data do leilão. Esses dados permitem indicar quais condições você quer esclarecer antes de decidir.</p><a class="underlink" href="guias/leiloes.html">Consultar o guia de leilões</a></div>
          </details>
          <details><summary>Devo enviar documentos pelo WhatsApp logo no início?</summary>
            <div><p>Para começar, basta indicar o assunto. Combine o canal de envio com a advogada antes de compartilhar documentos pessoais, endereços completos ou informações de terceiros.</p></div>
          </details>
        </div>
      </div>
    </section>
    <section id="contato" class="contact" aria-labelledby="tit-contato">
      <div class="shell contact-grid">
        <div>
          <p class="eyebrow">Atendimento em São Paulo</p>
          <h2 id="tit-contato">Contato com<br><em>o escritório.</em></h2>
          <p>Na primeira mensagem, basta indicar o assunto. Combine o envio de documentos diretamente com a advogada.</p>
          {botao_whatsapp(classe="light-button")}
        </div>
        <address class="channels">
          <div>{icone("telefone")}<div><h3>Telefone</h3><a href="{TEL_URL}">{TELEFONE}</a></div></div>
          <div>{icone("email")}<div><h3>E-mail</h3><a href="mailto:{EMAIL}">{EMAIL}</a></div></div>
          <div>{icone("local")}<div><h3>Localização</h3><p>Rua Jaceru, São Paulo – SP</p><small>Próximo às estações Brooklin e Morumbi.</small></div></div>
        </address>
      </div>
    </section>
  </main>'''

def lista_itens(itens):
    return "\n".join(f"              <li>{escape(item)}</li>" for item in itens)

def pagina_guia(guia):
    area = guia["area"]
    itens = "\n".join(
        f'''            <li><label><input type="checkbox" autocomplete="off"><span><strong>{nome}</strong><span>{texto}</span></span></label></li>'''
        for nome, texto in guia["lista"]
    )
    paragrafos = "\n".join(f"            <p>{p}</p>" for p in guia["contexto"])
    referencias = "\n".join(
        f'              <li><a href="{url}" rel="noreferrer">{label}</a></li>' for label, url in guia["fontes"]
    )
    return f'''
  <main id="principal" tabindex="-1">
    <div class="guide-heading">
      <div class="shell">
        <nav class="crumbs" aria-label="Caminho de navegação"><a href="../index.html">Início</a><span aria-hidden="true">/</span><a href="../index.html#atuacao">Áreas de atuação</a></nav>
        <div class="eyebrow">Guia de orientação</div>
        <h1>{area}</h1>
        <p>{guia["resumo"]}</p>
      </div>
    </div>
    <div class="shell guide-grid">
      <article class="guide-copy">
        <h2>Por onde começar</h2>
{paragrafos}
        <h2>Perguntas para a consulta</h2>
        <ul class="body-list">{lista_itens(guia["perguntas"])}</ul>
        <div class="legal-sources"><h3>Referência legal</h3><ul>{referencias}</ul></div>
      </article>
      <aside class="checklist" aria-labelledby="check-title">
        <div class="check-title">{icone("lista")}<h2 id="check-title">O que separar</h2></div>
        <p>Marque o que você já tem para a primeira conversa.</p>
        <span class="check-count" aria-live="polite" aria-atomic="true" hidden></span>
        <ul class="check-items">
{itens}
        </ul>
        <button type="button" class="button secondary-button print-button" hidden>{icone("imprimir")}Imprimir guia</button>
      </aside>
    </div>
    <div class="guide-bottom"><div class="shell guide-next"><div><h2>Quer conversar sobre o seu imóvel?</h2><p>{NOME} · {OAB}</p></div>{botao_whatsapp(classe="dark-button")}</div></div>
    <p class="print-contact">{NOME} · {OAB} · {TELEFONE} · {EMAIL}</p>
  </main>'''

def pagina_privacidade():
    return f'''
  <main id="principal" tabindex="-1" class="privacy">
    <div class="guide-heading"><div class="shell">
      <nav class="crumbs" aria-label="Caminho de navegação"><a href="index.html">Início</a><span aria-hidden="true">/</span><span>Privacidade</span></nav>
      <h1>Privacidade no site</h1>
      <p>Como funcionam a navegação, as listas de documentos e os canais de contato.</p>
    </div></div>
    <article class="shell privacy-copy">
      <h2>Durante a navegação</h2>
      <p>As páginas, imagens e fontes são carregadas pela própria hospedagem. O código do escritório não instala cookies de medição ou de publicidade, não utiliza ferramentas de análise de visitantes e não armazena os itens que você marca nos guias.</p>
      <p>A hospedagem pode processar informações técnicas da conexão para disponibilizar o site. No endereço público em github.io, o GitHub Pages registra o endereço IP do visitante para fins de segurança. <a class="underlink" href="https://docs.github.com/pt/pages/getting-started-with-github-pages/what-is-github-pages#data-collection" rel="noreferrer">Informações do GitHub Pages</a>.</p>
      <h2>Quando você entra em contato</h2>
      <p>O botão de WhatsApp abre o serviço externo usando apenas o número do escritório. Você escolhe o que escrever e quando enviar. O link de e-mail abre o aplicativo configurado no seu dispositivo. Os serviços usados para enviar mensagens também aplicam suas próprias políticas de privacidade.</p>
      <p>O escritório recebe as informações que você decide enviar para responder ao contato e tratar da solicitação apresentada. Para combinar o envio de documentos, indique primeiro o assunto da conversa.</p>
      <h2>Contato sobre seus dados</h2>
      <p>Para esclarecer como seus dados são utilizados ou solicitar acesso, correção ou exclusão, escreva para <a class="underlink" href="mailto:{EMAIL}">{EMAIL}</a>. A responsável pelo contato é {NOME}, {OAB}.</p>
      <p class="privacy-back"><a class="underlink" href="index.html#contato">Voltar aos contatos do escritório</a></p>
    </article>
  </main>'''

def gravar(caminho, titulo, descricao, html, prefixo="", inicial=False):
    arquivo = DIST / caminho
    arquivo.parent.mkdir(parents=True, exist_ok=True)
    arquivo.write_text(documento(caminho, titulo, descricao, html, prefixo, inicial), encoding="utf-8")

def main():
    gravar("index.html", "Cristiane Pires | Advocacia Imobiliária em São Paulo",
           "Advocacia imobiliária em São Paulo. Consulte guias de usucapião, inventário, leilões e desocupação e encontre os canais do escritório de Cristiane Pires.",
           pagina_inicial(), inicial=True)
    for guia in GUIAS:
        gravar(f'guias/{guia["slug"]}.html', f'{guia["area"]} | Cristiane Pires Advocacia', guia["resumo"], pagina_guia(guia), "../")
    gravar("privacidade.html", "Privacidade | Cristiane Pires Advocacia",
           "Entenda como o site de Cristiane Pires funciona e como contatar o escritório sobre seus dados.", pagina_privacidade())
    caminhos = [""] + [f'guias/{g["slug"]}.html' for g in GUIAS] + ["privacidade.html"]
    entradas = "\n".join(f"  <url><loc>{BASE+p}</loc></url>" for p in caminhos)
    (DIST/"sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+entradas+"\n</urlset>\n", encoding="utf-8")
    # O GitHub Pages aplica a CSP do HTML. Este arquivo é para hosts que aceitam _headers.
    opcional = DIST.parent / "hospedagem-opcional"
    opcional.mkdir(exist_ok=True)
    (opcional / "_headers").write_text(
        "/*\n"
        f"  Content-Security-Policy: {CSP}; frame-ancestors 'none'\n"
        "  X-Content-Type-Options: nosniff\n"
        "  X-Frame-Options: DENY\n"
        "  Referrer-Policy: no-referrer\n"
        "  Permissions-Policy: camera=(), microphone=(), geolocation=()\n"
        "  Strict-Transport-Security: max-age=31536000\n",
        encoding="utf-8",
    )

if __name__ == "__main__":
    main()
