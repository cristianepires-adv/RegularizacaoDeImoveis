# Cristiane Pires Advocacia

A versão revisada tem seis páginas estáticas em português. A página inicial apresenta a atuação da advogada e os canais de contato. Os quatro guias têm listas marcáveis e layout para impressão. A sexta página explica como o site trata os dados de navegação e contato.

## Revisão do site anterior

| Ponto observado | Alteração feita |
| --- | --- |
| O formulário pedia nome, telefone, e-mail e relato, e colocava os valores na URL enviada ao WhatsApp. | O botão usa somente o número do escritório. Quem visita escreve a mensagem dentro do aplicativo, se desejar. Telefone e e-mail também aceitam clique. |
| O botão principal pedia agendamento antes de explicar como o escritório poderia ajudar. | A pessoa pode entrar em contato de imediato ou escolher um guia relacionado ao que precisa resolver. |
| A seção de apresentação usava uma foto do Unsplash identificada como se fosse da advogada e trazia a afirmação “+80 imóveis regularizados”. | A apresentação usa a identidade visual fornecida, o nome profissional, a inscrição OAB/SP 436.779 e imagens ilustrativas. A redação descreve a atuação sem divulgar resultados de casos. |
| A animação começava ocultando o conteúdo e dependia do JavaScript para exibi-lo. O menu móvel era acionado por um elemento sem semântica de botão. | O conteúdo começa visível. O menu tem botão, foco e estado anunciado. As animações respeitam a preferência de movimento reduzido. |
| As quatro áreas eram textos curtos na página inicial. | Cada área ganhou endereço próprio, contexto, perguntas para a consulta, referência legal e lista que pode ser impressa ou salva em PDF pelo navegador. |

## Colocar no GitHub Pages

1. Descompacte o pacote. A pasta `dist/` contém a versão pronta para publicação.
2. No repositório `cristianepires-adv/RegularizacaoDeImoveis`, confira a origem de publicação em **Settings → Pages**. Se o Pages estiver configurado para a raiz da branch, coloque o **conteúdo** de `dist/` na raiz. Se estiver usando `/docs`, coloque o conteúdo dentro de `docs/`. Se já utilizar GitHub Actions, entregue esse mesmo conteúdo à etapa de publicação do fluxo atual.
3. Inclua `index.html`, `privacidade.html`, `sitemap.xml`, `.nojekyll` e as pastas `assets/` e `guias/`. O arquivo inicial deve ficar no mesmo nível das duas pastas. As pastas de manutenção e a pasta opcional de cabeçalhos ficam fora da área publicada.
4. Revise em uma branch separada e incorpore a alteração à branch de publicação. Depois que o deploy terminar, abra a página inicial no endereço existente e acesse um guia pelo menu de áreas. Confira também os links de telefone, e-mail e WhatsApp em um celular.
5. Em **Settings → Pages**, confira **Enforce HTTPS**. Para reverter esta revisão, reverta o commit de publicação.

O endereço público utilizado nos metadados e no mapa de páginas é [cristianepires-adv.github.io/RegularizacaoDeImoveis/](https://cristianepires-adv.github.io/RegularizacaoDeImoveis/).

[Origem de publicação do GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site) · [HTTPS no GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/securing-your-github-pages-site-with-https)

## Alterar textos e contatos

O site publicado funciona só com os arquivos estáticos. Para editar o nome, a OAB, os contatos ou os textos com manutenção centralizada, altere `gerar_paginas.py` e execute `python gerar_paginas.py` na pasta extraída. O comando atualiza as páginas e os cabeçalhos opcionais e calcula a assinatura de integridade do JavaScript. Rode-o também depois de alterar `dist/assets/site.js`. Os estilos ficam em `dist/assets/site.css`.

Para pré-visualizar localmente, execute `python -m http.server 8000 --bind 127.0.0.1 --directory dist` e abra `http://127.0.0.1:8000/`. Use `python3` no lugar de `python` se esse for o nome do interpretador no seu computador. A hospedagem pública dispensa Python.

## Segurança e privacidade

A Política de Segurança de Conteúdo de cada HTML restringe imagens, estilos e fontes à mesma origem e permite a execução do arquivo de JavaScript com o hash especificado. Os links externos usam uma política de referência restrita. A aplicação não contém formulários de envio, banco de dados, rastreadores ou armazenamento persistente das marcações. O menu sem JavaScript, os guias e os contatos continuam acessíveis em HTML. O GitHub Pages registra IPs para segurança da própria hospedagem.

O GitHub Pages gerencia os cabeçalhos HTTP de resposta. Em hospedagens que aceitam arquivos `_headers`, como Netlify, copie `hospedagem-opcional/_headers` para a raiz de publicação já servida por HTTPS. Essa configuração acrescenta restrições de enquadramento, interpretação de tipos de arquivo e permissões do navegador, além de HSTS. O bloqueio de enquadramento com `frame-ancestors` precisa ser enviado pelo servidor. A verificação foi feita no conteúdo do site e na navegação da versão de revisão. A configuração da conta e da infraestrutura de hospedagem fica a cargo de seu administrador.

[Dados de navegação no GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages#data-collection) · [CSP e enquadramento](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy/frame-ancestors) · [Cabeçalhos em hospedagem compatível](https://docs.netlify.com/manage/routing/headers/)

## O primeiro mês após a publicação

- **Descoberta.** No Google Search Console, confira por página as impressões e os cliques vindos da pesquisa. O endereço do mapa é o endereço público do site seguido de `sitemap.xml`. Um guia com impressões e poucos cliques é um bom candidato a um título que responda mais diretamente à pergunta buscada.
- **Atendimento.** Quando a pessoa mencionar o site, registre apenas o tema do contato e se houve agendamento, em totais por semana. Se a origem estiver incerta, uma pergunta opcional na conversa, “Como conheceu o escritório?”, já ajuda. Não registre relatos nem dados pessoais nessa contagem.
- **Resultado.** Compare consultas agendadas vindas do site com os novos contatos atribuídos ao site no mesmo período. Por exemplo, 3 consultas marcadas em 12 novos contatos equivalem a 25%. Um clique no WhatsApp, isoladamente, não comprova que uma conversa ocorreu.
- **Conteúdo seguinte.** Escolha a pergunta mais repetida nos contatos e transforme-a em uma orientação curta, revisada pela advogada. Havendo uma foto profissional autorizada, ela pode substituir a imagem ilustrativa da apresentação.

[Desempenho por página no Google Search Console](https://developers.google.com/search/blog/2024/12/recent-data-search-console?hl=pt-BR) · [Publicidade da advocacia, Provimento 205/2021](https://www.oab.org.br/leisnormas/legislacao/provimentos/205-2021) · [Identificação profissional, art. 44](https://www.oab.org.br/leisnormas/legislacao/resolucoes/07-2016)

## Créditos

Monograma e identidade do escritório fornecidos pelo titular do projeto. As imagens de arquitetura e da chave são ilustrações fotográficas geradas para esta versão. A fonte Noto Serif Display é distribuída sob a SIL Open Font License, incluída em `dist/assets/licenca-fontes.txt`.
